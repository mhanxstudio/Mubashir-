import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import Welcome from "./pages/Welcome";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";
import Blogs from "./pages/Blogs";
import ResumeDesign from "./pages/projects/ResumeDesign";
import DiaryApp from "./pages/projects/DiaryApp";
import GroceryStore from "./pages/projects/GroceryStore";
import CGIAnimation from "./pages/projects/CGIAnimation";
import BrandIdentity from "./pages/projects/BrandIdentity";
import SocialMediaContent from "./pages/projects/SocialMediaContent";
import BlogDetail from "./pages/BlogDetail";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem
      disableTransitionOnChange
    >
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Welcome />} />
              <Route path="/portfolio" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/blogs" element={<Blogs />} />
              <Route path="/blog/:slug" element={<BlogDetail />} />
              <Route path="/projects/resume-design" element={<ResumeDesign />} />
              <Route path="/projects/diary-app" element={<DiaryApp />} />
              <Route path="/projects/grocery-store" element={<GroceryStore />} />
              <Route path="/projects/cgi-animation" element={<CGIAnimation />} />
              <Route path="/projects/brand-identity" element={<BrandIdentity />} />
              <Route path="/projects/social-media-content" element={<SocialMediaContent />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
