import { useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Facebook, MessageCircle, User, Lock, ArrowRight, Heart, Sparkles, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

const Welcome = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const welcomeMessages = [
    "WELCOME",
    "CREATIVE WORLD",
    "LET'S CREATE"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % welcomeMessages.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #FCFCFC 0%, #FFFAE3 50%, #F7567C 100%)' }}>
      {/* Animated Background Elements - Organic Shapes */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Top Left Organic Shape */}
        <div className="absolute top-0 left-0 w-96 h-96 opacity-30">
          <div className="w-full h-full rounded-full" style={{ background: 'linear-gradient(135deg, #FFFAE3 0%, transparent 70%)' }}></div>
        </div>
        
        {/* Bottom Right Organic Shape */}
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] opacity-20">
          <div className="w-full h-full rounded-full" style={{ background: 'linear-gradient(315deg, #F7567C 0%, transparent 60%)' }}></div>
        </div>
        
        {/* Center Floating Elements */}
        <div className="absolute top-1/4 right-1/4 w-32 h-32 rounded-full opacity-25 animate-pulse" style={{ background: '#FFFAE3' }}></div>
        <div className="absolute bottom-1/3 left-1/5 w-24 h-24 rounded-full opacity-20 animate-pulse delay-1000" style={{ background: '#F7567C' }}></div>
      </div>

      {/* Character Illustrations Placeholder - Left Side */}
      <div className="absolute left-8 top-1/2 transform -translate-y-1/2 hidden lg:block">
        <div className="w-32 h-48 rounded-3xl opacity-60 animate-float" style={{ background: 'linear-gradient(45deg, #F7567C, #FFFAE3)' }}></div>
      </div>

      {/* Character Illustrations Placeholder - Right Side */}
      <div className="absolute right-8 bottom-20 hidden lg:block">
        <div className="w-28 h-44 rounded-3xl opacity-60 animate-float delay-1000" style={{ background: 'linear-gradient(225deg, #FFFAE3, #F7567C)' }}></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center px-6">
        <div className="max-w-md w-full">
          {/* Welcome Card */}
          <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/30">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="inline-block px-8 py-4 rounded-2xl mb-6" style={{ background: 'linear-gradient(135deg, #F7567C, #F7567C)' }}>
                <h1 className="text-bright-yellow text-2xl font-bold tracking-wide">
                  {welcomeMessages[currentIndex]}
                </h1>
              </div>
              
              <div className="space-y-2">
                <p className="text-bright-yellow text-lg font-medium">Hi, I'm Mubashir Hassan —</p>
                <p className="text-bright-yellow/90 text-base">turning ideas into stunning visuals</p>
                <p className="text-bright-yellow/90 text-base">that inspire and engage.</p>
              </div>
            </div>

            {/* Login Form */}
            <div className="space-y-4 mb-6">
              <div className="relative">
                <User className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input 
                  placeholder="Username" 
                  className="pl-12 py-3 bg-white/90 border-2 border-transparent focus:border-pink-bright rounded-full text-gray-700 placeholder-gray-400"
                />
              </div>
              
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input 
                  type="password" 
                  placeholder="Password" 
                  className="pl-12 py-3 bg-white/90 border-2 border-transparent focus:border-pink-bright rounded-full text-gray-700 placeholder-gray-400"
                />
              </div>
              
              <Button 
                className="w-full py-3 rounded-full font-bold text-bright-yellow text-lg transition-all duration-300 hover:scale-105 shadow-lg"
                style={{ background: 'linear-gradient(135deg, #F7567C, #F7567C)' }}
              >
                LOGIN
              </Button>
            </div>

            {/* Footer Links */}
            <div className="text-center space-y-4">
              <Link to="/auth" className="text-pink-bright hover:text-pink-dark transition-colors text-sm">
                Forgot Password?
              </Link>
              
              <div className="flex justify-between items-center text-sm">
                <span className="text-pink-bright cursor-pointer hover:text-pink-dark transition-colors">Remember</span>
                <Link to="/auth" className="text-pink-bright hover:text-pink-dark transition-colors">Create Account</Link>
              </div>
            </div>
          </div>

          {/* Social Connect Section */}
          <div className="mt-8 text-center">
            <p className="text-bright-yellow/90 mb-4">Connect with me on social media</p>
            <div className="flex justify-center space-x-4">
              <Button 
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-bright-yellow rounded-full px-4 py-2"
                onClick={() => window.open('https://facebook.com/yourpage', '_blank')}
              >
                <Facebook className="h-4 w-4 mr-2" />
                Facebook
              </Button>
              
              <Button 
                size="sm"
                className="bg-green-600 hover:bg-green-700 text-bright-yellow rounded-full px-4 py-2"
                onClick={() => window.open('https://wa.me/yournumber', '_blank')}
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>

          {/* Skip to Portfolio */}
          <div className="mt-6 text-center">
              <Link to="/portfolio">
                <Button 
                  variant="outline" 
                  className="bg-white/10 border-white/30 text-bright-yellow hover:bg-white/20 rounded-full px-6 py-2"
                >
                  Skip to Portfolio
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
          </div>
        </div>
      </div>


      {/* Social Connect Section */}
      <section id="social-connect" className="py-20 bg-navy/5">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-8">
            Stay Connected!
          </h2>
          
          <p className="text-xl text-navy-accent mb-12 max-w-2xl mx-auto">
            Follow my journey and get inspired by my latest work. Join our community for exclusive content and updates!
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Facebook Card */}
            <Card className="project-card border-blue-500/20 hover:border-blue-500/40 bg-gradient-to-br from-blue-50 to-blue-100/50">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Facebook className="h-10 w-10 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-4">Follow Our Facebook Page</h3>
                <p className="text-blue-700 mb-6">
                  Get daily inspiration, behind-the-scenes content, and connect with our creative community.
                </p>
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 text-bright-yellow px-8 py-3 rounded-full transition-all duration-300 hover:scale-105"
                  onClick={() => window.open('https://facebook.com/yourpage', '_blank')}
                >
                  <Facebook className="mr-2 h-5 w-5" />
                  Follow on Facebook
                </Button>
              </CardContent>
            </Card>

            {/* WhatsApp Card */}
            <Card className="project-card border-green-500/20 hover:border-green-500/40 bg-gradient-to-br from-green-50 to-green-100/50">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-green-900 mb-4">Join Our WhatsApp Channel</h3>
                <p className="text-green-700 mb-6">
                  Receive instant updates, exclusive offers, and direct communication with our team.
                </p>
                <Button 
                  className="bg-green-600 hover:bg-green-700 text-bright-yellow px-8 py-3 rounded-full transition-all duration-300 hover:scale-105"
                  onClick={() => window.open('https://wa.me/yournumber', '_blank')}
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Join WhatsApp Channel
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Special Offer Banner */}
          <div className="mt-16 p-8 glass-card max-w-2xl mx-auto">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="h-6 w-6 text-peachy mr-2" />
              <h3 className="text-2xl font-bold gradient-text">Special Offer!</h3>
              <Sparkles className="h-6 w-6 text-peachy ml-2" />
            </div>
            <p className="text-navy-accent mb-6">
              Follow both our Facebook page and WhatsApp channel to get 20% off on your first project!
            </p>
            <div className="flex justify-center space-x-4">
              <div className="flex items-center text-sm text-navy-accent">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                Exclusive Content
              </div>
              <div className="flex items-center text-sm text-navy-accent">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                Early Access
              </div>
              <div className="flex items-center text-sm text-navy-accent">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                Special Discounts
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-8">
            Ready to Start Your Journey?
          </h2>
          
          <p className="text-xl text-navy-accent mb-12 max-w-2xl mx-auto">
            Let's bring your creative vision to life. Browse my portfolio and see what we can create together.
          </p>

          <Link to="/portfolio">
            <Button className="hero-button text-lg px-12 py-6">
              View My Portfolio
              <ArrowRight className="ml-2 h-6 w-6" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Welcome;