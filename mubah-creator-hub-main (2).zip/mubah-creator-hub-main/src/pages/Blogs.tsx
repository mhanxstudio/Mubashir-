import { useState } from 'react';
import { ArrowLeft, Calendar, Clock, ArrowRight, Search, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Blogs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const blogPosts = [
    {
      id: 1,
      title: 'The Future of Web Design: Trends to Watch in 2025',
      excerpt: 'As we move into 2025, the web design landscape is transforming faster than ever. With emerging technologies, evolving aesthetics, and user experience taking center stage, web designers are stepping into a future that is immersive, intelligent, and deeply human-centered.',
      image: 'https://i.postimg.cc/MpqNFmtf/IMG-20250802-115700.jpg',
      category: 'Web Design',
      date: '2025-01-15',
      readTime: '8 min read',
      slug: 'future-web-design-2025',
      content: `
        <h2>🔮 1. Generative AI in Design Workflows</h2>
        <p>AI won't just assist—it will co-create. Designers in 2025 are leveraging tools like Figma AI, Adobe Firefly, and Midjourney to automatically generate layout ideas, color palettes, and even entire page templates. This boosts creativity while cutting design time dramatically.</p>
        
        <h2>🌐 2. Hyper-Personalized Experiences</h2>
        <p>With smarter tracking (ethical and consent-based), websites will adapt in real-time—changing visuals, content, and product recommendations based on user behavior, mood, location, and even device habits.</p>
        
        <h2>🖼️ 3. Cinematic Web Experiences</h2>
        <p>Expect more websites that feel like interactive films. Using full-screen video backgrounds, parallax 3D effects, ambient sound, and scroll-driven storytelling, brands will create immersive, movie-like digital journeys.</p>
        
        <h2>🎨 4. Retro-Futurism & Maximalism</h2>
        <p>While minimalism still holds ground, 2025 welcomes bold fonts, neon gradients, layered elements, and experimental layouts inspired by Y2K and sci-fi aesthetics. Designers are breaking traditional grids in favor of expressive chaos.</p>
        
        <h2>🧠 5. Neurodesign & Emotional UX</h2>
        <p>Websites are being crafted to trigger emotional responses—calmness, excitement, urgency. Through color psychology, sound cues, and motion rhythm, designers will tap into human cognition to boost retention and conversions.</p>
        
        <h2>🌈 6. Inclusive, Adaptive Design</h2>
        <p>2025 is the year of total accessibility. Expect voice-controlled navigation, real-time text-to-speech, motion-reduced versions, and interfaces that adapt to neurodivergent users—making the web welcoming for all.</p>
        
        <h2>📱 7. Mobile-First is Now Mobile-Only</h2>
        <p>With smartphones being the primary screen, many designers will ditch desktop-first altogether. Expect thumb-friendly UI, minimal navigation bars, gesture controls, and even vertical video integration on homepages.</p>
        
        <h2>🛍️ 8. Instant Commerce Integration</h2>
        <p>Websites will embed direct shopping experiences everywhere—no redirects, no third-party carts. One-click checkout, AR try-ons, and virtual assistants will define future ecommerce UX.</p>
        
        <h2>🧩 9. No-Code & Low-Code Expansion</h2>
        <p>More creatives will design functional web apps without writing code. Platforms like Webflow, Framer, and Glide will empower solo designers to launch production-ready experiences—fast and scalable.</p>
        
        <h2>🦾 10. Ethical, Sustainable Design</h2>
        <p>With increasing climate awareness, carbon-efficient websites will rise. Lighter pages, eco-hosting, and minimal resource usage will become standard, along with ethical data practices.</p>
        
        <h2>🚀 Final Thoughts</h2>
        <p>Web design in 2025 is no longer just about looks—it's about emotions, ethics, and experiences. The future belongs to designers who blend creativity with technology, empathy with strategy, and innovation with responsibility.</p>
      `
    },
    {
      id: 2,
      title: 'Creating Stunning CGI Animations for Marketing',
      excerpt: 'In today\'s fast-moving digital world, attention spans are short, and competition is fierce. Brands are constantly seeking fresh, impactful ways to stand out—and that\'s where CGI (Computer-Generated Imagery) animations come in.',
      image: 'https://i.postimg.cc/MT9pnGTd/IMG-20250802-120142.jpg',
      category: 'Animation',
      date: '2025-01-10',
      readTime: '10 min read',
      slug: 'cgi-animations-marketing',
      content: `
        <h2>🎯 Why CGI in Marketing?</h2>
        <p>Traditional video is powerful—but CGI takes it a step further. It allows brands to visualize what doesn't yet exist, craft impossible scenarios, and present products in a futuristic, cinematic light. Whether it's a smartphone unboxing in space or a perfume bottle emerging from a digital waterfall, CGI turns ideas into stunning visual stories.</p>
        
        <h2>🧠 The Core Benefits of CGI for Marketers</h2>
        <ul>
          <li><strong>Limitless Creativity:</strong> No need for physical locations, props, or perfect weather. Create anything you imagine.</li>
          <li><strong>Cost-Effective:</strong> Once the model is created, it can be reused across different campaigns with variations.</li>
          <li><strong>Futuristic Appeal:</strong> CGI gives your brand a modern, tech-savvy edge—perfect for tech, fashion, automotive, and lifestyle brands.</li>
          <li><strong>Precision Detailing:</strong> Highlight product features at microscopic levels, rotate objects in 3D, or explode parts to show inner workings.</li>
        </ul>
        
        <h2>🛠️ Steps to Create Stunning CGI Animations</h2>
        <ol>
          <li><strong>Concept & Storyboarding:</strong> Start with a strong narrative or visual concept. What's the message? Who's your audience? Use a storyboard to plan key shots and scenes.</li>
          <li><strong>3D Modeling:</strong> Create digital 3D models of the product or scene using software like Blender, Cinema 4D, or Maya. The more detailed your model, the more realistic the final result.</li>
          <li><strong>Texturing & Lighting:</strong> Apply materials (metal, glass, plastic, etc.) and realistic lighting. This stage gives life and texture to the objects.</li>
          <li><strong>Animation:</strong> Animate your models with camera movements, rotations, object transformations, or even character interactions. Smooth motion is key to visual appeal.</li>
          <li><strong>Rendering:</strong> Render each frame of the animation. This is a time-consuming but essential step to get cinematic-quality visuals.</li>
          <li><strong>Post-Production:</strong> Use software like After Effects or DaVinci Resolve to add final touches—color correction, sound design, motion blur, and branding.</li>
        </ol>
        
        <h2>🔥 Top CGI Marketing Trends in 2025</h2>
        <ul>
          <li><strong>CGI Unboxings:</strong> Products dropping from the sky, opening with mechanical precision.</li>
          <li><strong>Digital Twins:</strong> Hyper-realistic virtual versions of real-world products.</li>
          <li><strong>Augmented CGI:</strong> Integrating CGI elements into real-world footage for hybrid experiences.</li>
          <li><strong>360° Animations:</strong> Interactive product animations that the user can rotate or explore.</li>
          <li><strong>CGI + AI:</strong> AI-generated voiceovers, scripts, and music are pairing with CGI for faster production.</li>
        </ul>
        
        <h2>🚀 Final Thoughts</h2>
        <p>CGI animation isn't just a visual gimmick—it's a storytelling tool. When done right, it transforms your product into an experience. It elevates brand perception, drives engagement, and sparks emotional connections with viewers.</p>
      `
    },
    {
      id: 3,
      title: 'UI/UX Design Best Practices for Mobile Apps in 2025',
      excerpt: 'In a world dominated by smartphones, mobile app design is more than just making things look pretty—it\'s about crafting seamless, intuitive, and delightful user experiences.',
      image: 'https://i.postimg.cc/nV5Q2dFT/IMG-20250802-120927.jpg',
      category: 'UI/UX',
      date: '2025-01-05',
      readTime: '12 min read',
      slug: 'mobile-app-design-practices',
      content: `
        <h2>📱 1. Design for Thumb Zones</h2>
        <p>Most users operate their phones with one hand. Keep key actions (like navigation, search, or call-to-action buttons) within easy thumb reach—especially in the bottom third of the screen.</p>
        <p><strong>🟢 Pro Tip:</strong> Use bottom navigation bars instead of top tabs for better reachability.</p>
        
        <h2>🎯 2. Clarity Over Complexity</h2>
        <p>Simplicity wins. Avoid overcrowded screens. Use clear visual hierarchy, enough white space, and a single primary action per screen to guide users efficiently.</p>
        <p><strong>🟢 Pro Tip:</strong> Use the "one screen, one purpose" rule.</p>
        
        <h2>🌙 3. Include Light & Dark Modes</h2>
        <p>With more users preferring customizable experiences, dark mode support is a must. It reduces eye strain and improves battery life on OLED screens.</p>
        <p><strong>🟢 Pro Tip:</strong> Ensure readability by testing color contrast in both modes.</p>
        
        <h2>⚡ 4. Fast Load Times & Smooth Transitions</h2>
        <p>Speed is UX. Apps should load in under 3 seconds, and transitions should be smooth, subtle, and logical—not flashy or overdone.</p>
        <p><strong>🟢 Pro Tip:</strong> Use loading indicators or animations to keep users engaged during delays.</p>
        
        <h2>🔍 5. Accessible Design</h2>
        <p>Design for everyone—including people with visual, motor, or cognitive impairments. Use scalable fonts, alt text, voice navigation, and high-contrast UI.</p>
        <p><strong>🟢 Pro Tip:</strong> Follow WCAG and test your app with accessibility tools like TalkBack or VoiceOver.</p>
        
        <h2>🧭 6. Intuitive Navigation</h2>
        <p>Users should never feel lost. Use clear icons, breadcrumb trails, and back navigation. Keep menus shallow—no more than 2–3 levels deep.</p>
        <p><strong>🟢 Pro Tip:</strong> Stick to familiar iconography (e.g., a gear for settings, magnifier for search).</p>
        
        <h2>🔄 7. Consistency Across Screens</h2>
        <p>Use consistent fonts, colors, and layout patterns throughout the app. This builds trust and familiarity, reducing the learning curve.</p>
        <p><strong>🟢 Pro Tip:</strong> Build and stick to a design system or component library.</p>
        
        <h2>📊 8. Micro-Interactions Enhance UX</h2>
        <p>Subtle animations (button taps, swipe feedback, etc.) create delightful experiences and reinforce user actions. But keep them quick and purposeful.</p>
        <p><strong>🟢 Pro Tip:</strong> Use Lottie animations for lightweight, scalable micro-interactions.</p>
        
        <h2>🧠 9. User Testing Early & Often</h2>
        <p>Don't guess—test. Run usability tests with real users during prototyping, not just after launch. Small feedback loops save time and money.</p>
        <p><strong>🟢 Pro Tip:</strong> Use tools like Maze, Useberry, or Figma prototypes to collect feedback fast.</p>
        
        <h2>🔐 10. Secure, Yet Friendly Onboarding</h2>
        <p>First impressions matter. Onboard users quickly with tooltips, welcome screens, and optional walkthroughs. Avoid overloading them with permissions on the first tap.</p>
        <p><strong>🟢 Pro Tip:</strong> Delay non-essential permission requests until they're needed.</p>
        
        <h2>🚀 Final Thoughts</h2>
        <p>Great mobile app design isn't just about aesthetics—it's about usability, inclusivity, performance, and emotion. As mobile use continues to rise, designers and developers must align with best practices to build apps that are not just usable—but lovable.</p>
      `
    },
    {
      id: 4,
      title: 'Brand Identity Design: Building Visual Recognition',
      excerpt: 'In an era of infinite choices, a brand that stands out visually has a powerful advantage. Whether it\'s the iconic Nike swoosh or the unmistakable color of Coca-Cola, brand identity is what makes businesses instantly recognizable, trusted, and memorable.',
      image: 'https://i.postimg.cc/wj9JR1Td/1754118619713.png',
      category: 'Branding',
      date: '2024-12-28',
      readTime: '15 min read',
      slug: 'brand-identity-design-guide',
      content: `
        <h2>🎯 What Is Brand Identity?</h2>
        <p>Brand identity is more than just a logo. It's the visual language of your brand, including your:</p>
        <ul>
          <li>Logo</li>
          <li>Color palette</li>
          <li>Typography</li>
          <li>Iconography</li>
          <li>Graphic elements</li>
          <li>Photography style</li>
          <li>Packaging (if applicable)</li>
        </ul>
        <p>Together, these form a consistent visual system that communicates your brand's personality, values, and promise.</p>
        
        <h2>🧠 Why Visual Recognition Matters</h2>
        <p>People remember 80% of what they see—but only 20% of what they read. Strong visual branding leads to:</p>
        <ul>
          <li>Instant Recognition</li>
          <li>Emotional Connection</li>
          <li>Brand Trust & Loyalty</li>
          <li>Higher Conversion Rates</li>
        </ul>
        <p>Your visual identity is often the first—and most lasting—impression your audience will have.</p>
        
        <h2>🛠️ The Key Elements of Strong Brand Identity</h2>
        
        <h3>1. Logo Design</h3>
        <p>Your logo is your signature. It must be simple, versatile, and timeless. Avoid trends that will feel outdated in a year.</p>
        <p><strong>🟢 Tip:</strong> Test your logo in black & white and at small sizes for flexibility.</p>
        
        <h3>2. Color Palette</h3>
        <p>Colors evoke emotion. A strategic color scheme strengthens your message and affects how people perceive your brand.</p>
        <p><strong>🔵 Example:</strong> Blue for trust (banks), red for excitement (entertainment), green for health (organic products).</p>
        
        <h3>3. Typography</h3>
        <p>Fonts speak. Choose 1–2 primary typefaces that reflect your tone—modern, playful, bold, elegant, etc.—and use them consistently.</p>
        <p><strong>🟢 Pro Tip:</strong> Pair a decorative headline font with a clean, readable body font.</p>
        
        <h3>4. Visual Style & Graphics</h3>
        <p>Icons, textures, line styles, photo filters—all of these build visual unity. Develop a visual language that fits your industry and audience.</p>
        
        <h3>5. Brand Guidelines (Style Guide)</h3>
        <p>Create a clear brand guide that outlines how your visuals should be used. This ensures consistency across all platforms—social, web, packaging, print, and ads.</p>
        <p><strong>📘 Include:</strong> Logo usage, spacing rules, do's & don'ts, color codes, fonts, and imagery examples.</p>
        
        <h2>💡 Case Study: Apple</h2>
        <p>Apple's brand identity is built on minimalism, elegance, and innovation. From its clean white packaging to its San Francisco font and iconic bitten apple logo—every design decision is intentional and aligned with its values. That's the power of consistent branding.</p>
        
        <h2>✅ Final Checklist for Strong Brand Identity</h2>
        <ul>
          <li>✔ A memorable, versatile logo</li>
          <li>✔ Strategic and emotional color palette</li>
          <li>✔ Consistent typography</li>
          <li>✔ Scalable and flexible design system</li>
          <li>✔ Brand style guide</li>
          <li>✔ Clear alignment with your brand's story and values</li>
          <li>✔ Designed for your audience—not your personal preferences</li>
        </ul>
        
        <h2>🚀 Conclusion</h2>
        <p>A strong brand identity isn't just "nice to have"—it's a business asset. When done right, it creates trust, emotional connection, and long-term recognition. Whether you're building a startup, launching a product, or rebranding an established business, remember:</p>
        <blockquote>"People ignore design that ignores people." – Frank Chimero</blockquote>
      `
    },
    {
      id: 5,
      title: 'Video Editing Techniques for Social Media Success',
      excerpt: 'In today\'s fast-paced digital world, video is king—and nowhere is this more true than on social media. But raw footage alone isn\'t enough. To stand out, capture attention, and convert viewers into followers (and customers), you need to master the art of video editing.',
      image: 'https://i.postimg.cc/439JJ5k4/IMG-20250802-121211.jpg',
      category: 'Video Editing',
      date: '2024-12-20',
      readTime: '11 min read',
      slug: 'video-editing-social-media',
      content: `
        <h2>🎬 1. Hook Within the First 3 Seconds</h2>
        <p>Social media users scroll fast—your video must grab attention immediately.</p>
        <ul>
          <li>✅ Use bold text</li>
          <li>✅ Ask a question</li>
          <li>✅ Show something visually unexpected</li>
          <li>✅ Use punchy audio</li>
        </ul>
        <p><strong>Pro Tip:</strong> Trim the intro; start with the action.</p>
        
        <h2>✂️ 2. Cut Fast, Keep It Snappy</h2>
        <p>Modern social platforms favor fast-paced editing. Long pauses or slow scenes? Cut them.</p>
        <p>🎥 Use jump cuts, match cuts, or J/L cuts to maintain flow and keep energy high.</p>
        
        <h2>🎵 3. Use Trending & Relevant Music</h2>
        <p>Sound is 50% of the experience. Use trending audio for better reach—especially on Instagram Reels and TikTok.</p>
        <p>🎧 Sync your cuts to the beat for more professional rhythm and feel.</p>
        
        <h2>💬 4. Add Captions & Text Overlays</h2>
        <p>Most users watch without sound. Adding captions boosts accessibility and watch time.</p>
        <p>📝 Highlight keywords or phrases using animated text to reinforce your message.</p>
        
        <h2>🌈 5. Use Dynamic Transitions</h2>
        <p>Creative transitions—like swipes, zooms, masks, or glitch effects—help keep the viewer engaged, especially when switching scenes.</p>
        <p>🎨 But don't overdo it. Too many transitions can feel chaotic.</p>
        
        <h2>🔍 6. Zoom, Crop & Reframe for Emphasis</h2>
        <p>Use digital zoom-ins to emphasize reactions, expressions, or product features. This keeps the viewer focused where you want them.</p>
        <p>📱 Especially useful for mobile-first vertical videos.</p>
        
        <h2>🔁 7. Loop-Friendly Editing</h2>
        <p>Make your video seamlessly loop if it's short (under 15 seconds). It increases repeat views and watch time.</p>
        <p>🔄 Repeat audio or match your ending shot to your opening frame.</p>
        
        <h2>🧠 8. Tell a Story – Even in 15 Seconds</h2>
        <p>Even short videos need a clear structure:</p>
        <ul>
          <li>Hook (problem or teaser)</li>
          <li>Body (showcase, tutorial, reaction)</li>
          <li>Payoff (result, surprise, CTA)</li>
        </ul>
        <p>🎥 Keep storytelling concise but compelling.</p>
        
        <h2>🚀 9. Always Add a Call-To-Action (CTA)</h2>
        <p>Whether it's "Follow for more," "Link in bio," or "Comment below"—guide your audience on what to do next.</p>
        <p>📌 Use on-screen text or voiceover to make your CTA visible and actionable.</p>
        
        <h2>🛠️ 10. Use the Right Editing Tools</h2>
        <p>Top tools for fast, social-first editing:</p>
        <ul>
          <li><strong>CapCut</strong> (Best for TikTok/Reels – free and powerful)</li>
          <li><strong>InShot</strong> (Simple and mobile-friendly)</li>
          <li><strong>Adobe Premiere Rush</strong> (Great for branded content)</li>
          <li><strong>VN Editor</strong> (Fast and flexible)</li>
          <li><strong>DaVinci Resolve</strong> (Pro-level features for YouTube)</li>
        </ul>
        
        <h2>📊 Bonus: Optimize for Each Platform</h2>
        <ul>
          <li><strong>Instagram Reels:</strong> Vertical, <60s, bold hooks, high energy</li>
          <li><strong>TikTok:</strong> Trend-driven, funny or emotional, fast pace</li>
          <li><strong>YouTube Shorts:</strong> Informative or funny, subtle branding</li>
          <li><strong>Facebook Video:</strong> Slightly longer, more storytelling</li>
        </ul>
        
        <h2>✅ Final Thoughts</h2>
        <p>Great video editing isn't just about effects—it's about strategy, story, and style. When your edits reflect your brand's voice and are tailored to platform trends, your videos will connect, convert, and grow your audience.</p>
        <p>🎯 Keep it short. Make it sharp. And always lead with value.</p>
      `
    },
    {
      id: 6,
      title: 'Getting Started as a Freelance Designer',
      excerpt: 'Breaking into the world of freelance design can feel overwhelming—especially when you\'re young. But the truth is, age doesn\'t matter—skills, mindset, and consistency do.',
      image: 'https://i.postimg.cc/ZR4X1FJM/IMG-20250802-121358.jpg',
      category: 'Career',
      date: '2024-12-15',
      readTime: '14 min read',
      slug: 'freelance-designer-guide',
      content: `
        <h2>🎨 1. Master Your Craft</h2>
        <p>Before you offer services, you need skills that deliver real value.</p>
        <ul>
          <li>Choose your focus: logo design, UI/UX, social media graphics, animation, or web design.</li>
          <li>Learn tools like Adobe Photoshop, Illustrator, Figma, Canva, Blender, or After Effects (depending on your niche).</li>
          <li>Take free or affordable courses (YouTube, Skillshare, Coursera, etc.).</li>
        </ul>
        <p><strong>🟢 Tip:</strong> Start with small practice projects for friends, family, or personal mock brands.</p>
        
        <h2>💼 2. Build a Killer Portfolio</h2>
        <p>Your portfolio is your first impression—make it count. Even if you haven't had real clients, create concept projects that showcase your style and problem-solving.</p>
        <ul>
          <li>✅ Show 5–6 strong, diverse samples</li>
          <li>✅ Include a short explanation of your thought process</li>
          <li>✅ Use free platforms like Behance, Dribbble, or your own website</li>
        </ul>
        
        <h2>🌐 3. Create Your Online Presence</h2>
        <p>In 2025, if you're not online, you don't exist.</p>
        <ul>
          <li>Build a personal brand name and consistent username</li>
          <li>Create an Instagram page or LinkedIn profile showcasing your work</li>
          <li>Build a simple portfolio website using tools like Wix, Framer, or Webflow</li>
          <li>Share reels, timelapses, or before/after edits of your work</li>
        </ul>
        <p><strong>🟢 Tip:</strong> Your name, face, and story build trust—don't be afraid to show them.</p>
        
        <h2>🤝 4. Find Your First Clients</h2>
        <p>Start small—but start.</p>
        <ul>
          <li>Reach out to small businesses, startups, or student-led projects</li>
          <li>Join freelance platforms like Fiverr, Upwork, Freelancer, or Contra</li>
          <li>Use Facebook groups, Reddit threads, or Discord communities to offer help</li>
          <li>Offer discounted or free work to build experience and reviews—but don't do it forever</li>
        </ul>
        <p><strong>🟢 Tip:</strong> Word-of-mouth is powerful. Make every client your best promoter.</p>
        
        <h2>💬 5. Learn to Communicate Like a Pro</h2>
        <p>Your design skill gets you noticed. Your communication wins the client.</p>
        <ul>
          <li>Be polite, clear, and confident</li>
          <li>Ask questions, send drafts, and confirm feedback</li>
          <li>Always clarify deadlines, revisions, and payment terms</li>
        </ul>
        <p><strong>🟢 Pro Tip:</strong> Use tools like Notion or Trello to stay organized.</p>
        
        <h2>💰 6. Set Prices That Respect Your Work</h2>
        <p>Don't undervalue your time—charge based on value, not age.</p>
        <ul>
          <li>Start with basic hourly rates ($10–$25) or project-based pricing</li>
          <li>Raise rates as your portfolio and experience grow</li>
          <li>Use PayPal, Wise, or Stripe for smooth payments</li>
        </ul>
        <p><strong>🟢 Tip:</strong> Make a simple price sheet for transparency.</p>
        
        <h2>🧠 7. Keep Learning, Always</h2>
        <p>Design trends, tools, and tech evolve constantly.</p>
        <ul>
          <li>Follow top designers and design blogs</li>
          <li>Watch YouTube breakdowns and case studies</li>
          <li>Stay updated on UI/UX, animation trends, and design psychology</li>
        </ul>
        <p><strong>🟢 Tip:</strong> Learn about client behavior, business, and soft skills too—it's not just about visuals.</p>
        
        <h2>🚀 Final Thoughts</h2>
        <p>Starting as a freelance designer at a young age isn't easy—but it's absolutely possible. You have the energy, time, and curiosity that many seasoned pros wish they still had.</p>
        <p>Stay consistent. Keep improving. Focus on real value, not just likes.</p>
        <blockquote>"Don't wait to be discovered. Create, share, and show the world what you can do."</blockquote>
      `
    }
  ];

  const categories = ['all', 'Web Design', 'Animation', 'UI/UX', 'Branding', 'Video Editing', 'Career'];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="inline-flex items-center text-navy hover:text-peachy transition-colors">
              <ArrowLeft size={20} className="mr-2" />
              Back to Portfolio
            </Link>
            <h1 className="text-xl font-bold text-navy">Creative Insights</h1>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-peachy-light/20 to-navy/5">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-navy mb-6 fade-in">
            Creative <span className="text-peachy">Insights</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed fade-in">
            Explore tutorials, creative thoughts, and insights about design, development, and digital creation
          </p>
          <div className="w-24 h-1 bg-peachy mx-auto rounded-full mt-8"></div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-card">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory === category ? "bg-peachy hover:bg-peachy/90" : ""}
                >
                  {category === 'all' ? 'All Posts' : category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, index) => (
              <article 
                key={post.id}
                className="group bg-card rounded-3xl overflow-hidden shadow-premium hover:shadow-neon transition-all duration-500 hover:-translate-y-2 fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Featured Image */}
                <div className="relative h-48 bg-gradient-to-br from-peachy-light to-navy/10 overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-navy/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Link to={`/blog/${post.slug}`}>
                      <Button size="sm" className="bg-white text-navy hover:bg-peachy-light">
                        <ArrowRight size={16} className="mr-2" />
                        Read More
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  {/* Meta */}
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center space-x-2">
                      <Tag size={14} />
                      <span className="bg-peachy-light text-peachy px-2 py-1 rounded-full text-xs font-medium">
                        {post.category}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Calendar size={14} />
                        <span>{new Date(post.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock size={14} />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-navy group-hover:text-peachy transition-colors line-clamp-2">
                    {post.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-muted-foreground leading-relaxed line-clamp-3">
                    {post.excerpt}
                  </p>

                  {/* Read More Link */}
                  <Link 
                    to={`/blog/${post.slug}`}
                    className="inline-flex items-center text-peachy font-medium hover:text-peachy-dark transition-colors group/link"
                  >
                    Read Full Article
                    <ArrowRight size={16} className="ml-2 group-hover/link:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </article>
            ))}
          </div>

          {/* No Results */}
          {filteredPosts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No articles found matching your criteria.</p>
              <Button 
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                }}
                className="mt-4"
                variant="outline"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 bg-navy">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-bright-yellow mb-4">Stay Updated</h2>
          <p className="text-bright-yellow/80 mb-8 max-w-2xl mx-auto">
            Get notified when I publish new articles, tutorials, and creative insights.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input 
              placeholder="Enter your email"
              className="bg-white/10 border-white/20 text-bright-yellow placeholder:text-bright-yellow/60"
            />
            <Button className="bg-peachy hover:bg-peachy/90 text-navy">
              Subscribe
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blogs;