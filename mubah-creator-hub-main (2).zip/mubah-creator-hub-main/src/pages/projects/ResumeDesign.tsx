import { ArrowLeft, Download, Star, Clock, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import resumeTemplate from '@/assets/resume-template.png';

const ResumeDesign = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-6 py-4">
          <Link to="/" className="inline-flex items-center text-navy hover:text-peachy transition-colors">
            <ArrowLeft size={20} className="mr-2" />
            Back to Portfolio
          </Link>
        </div>
      </header>

      {/* Project Details */}
      <div className="container mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Project Image */}
          <div className="space-y-6">
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img 
                src={resumeTemplate} 
                alt="Professional Resume Template"
                className="w-full h-auto"
              />
            </div>
          </div>

          {/* Project Info */}
          <div className="space-y-8">
            <div>
              <span className="inline-block px-3 py-1 bg-peachy-light text-peachy text-sm font-medium rounded-full mb-4">
                Design
              </span>
              <h1 className="text-4xl font-bold text-navy mb-4">
                Professional Resume Designs
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Modern, ATS-friendly resume templates with clean layouts and professional typography. 
                These templates are designed to help job seekers stand out while maintaining 
                professional standards and ensuring compatibility with Applicant Tracking Systems.
              </p>
            </div>

            {/* Project Stats */}
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <Star className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">15+</div>
                  <div className="text-sm text-muted-foreground">Templates</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Clock className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">2-3</div>
                  <div className="text-sm text-muted-foreground">Days</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Users className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">50+</div>
                  <div className="text-sm text-muted-foreground">Happy Clients</div>
                </CardContent>
              </Card>
            </div>

            {/* Technologies */}
            <div>
              <h3 className="text-xl font-semibold text-navy mb-4">Technologies Used</h3>
              <div className="flex flex-wrap gap-2">
                {['Adobe Illustrator', 'Figma', 'Canva'].map((tech) => (
                  <span 
                    key={tech}
                    className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-full"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Order Section */}
            <Card className="bg-gradient-to-r from-peachy-light to-muted">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-navy mb-4">Order This Project</h3>
                <p className="text-muted-foreground mb-6">
                  Get a custom resume design tailored to your industry and experience level.
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="font-medium">Starting Price:</span>
                    <span className="font-bold text-peachy">$15</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Delivery Time:</span>
                    <span className="font-bold">1-2 Days</span>
                  </div>
                  <Button className="w-full bg-peachy hover:bg-peachy/90 text-bright-yellow">
                    Order Now
                  </Button>
                  <Button variant="outline" className="w-full">
                    Contact for Custom Quote
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Detailed Description */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-navy mb-8">Project Details</h2>
          <div className="prose max-w-none">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-navy mb-4">What's Included</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Modern, clean design layout</li>
                  <li>• ATS-friendly formatting</li>
                  <li>• Multiple format options (PDF, DOCX)</li>
                  <li>• Professional typography</li>
                  <li>• Color variations</li>
                  <li>• Free revisions (up to 3)</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-navy mb-4">Why Choose This Design</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Optimized for applicant tracking systems</li>
                  <li>• Industry-specific customization</li>
                  <li>• Professional appearance</li>
                  <li>• Easy to customize and update</li>
                  <li>• Proven to increase interview calls</li>
                  <li>• Compatible with all major platforms</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeDesign;