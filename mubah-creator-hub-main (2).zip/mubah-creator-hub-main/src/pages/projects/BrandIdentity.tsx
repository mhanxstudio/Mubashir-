import { ArrowLeft, Palette, Award, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import brandIdentityPackage from '@/assets/brand-identity-package.jpg';

const BrandIdentity = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-6 py-4">
          <Link to="/" className="inline-flex items-center text-navy hover:text-peachy transition-colors">
            <ArrowLeft size={20} className="mr-2" />
            Back to Portfolio
          </Link>
        </div>
      </header>

      {/* Project Details */}
      <div className="container mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Project Image */}
          <div className="space-y-6">
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img 
                src={brandIdentityPackage} 
                alt="Brand Identity Package"
                className="w-full h-auto"
              />
            </div>
          </div>

          {/* Project Info */}
          <div className="space-y-8">
            <div>
              <span className="inline-block px-3 py-1 bg-peachy-light text-peachy text-sm font-medium rounded-full mb-4">
                Branding
              </span>
              <h1 className="text-4xl font-bold text-navy mb-4">
                Brand Identity Package
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Complete brand identity including logo design, color palette, and brand guidelines. 
                This comprehensive package establishes a strong, cohesive visual identity that 
                communicates your brand values and resonates with your target audience across 
                all touchpoints and marketing materials.
              </p>
            </div>

            {/* Project Stats */}
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <Palette className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">100+</div>
                  <div className="text-sm text-muted-foreground">Designs</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Award className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">5-7</div>
                  <div className="text-sm text-muted-foreground">Days</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Users className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">75+</div>
                  <div className="text-sm text-muted-foreground">Brands Created</div>
                </CardContent>
              </Card>
            </div>

            {/* Technologies */}
            <div>
              <h3 className="text-xl font-semibold text-navy mb-4">Technologies Used</h3>
              <div className="flex flex-wrap gap-2">
                {['Adobe Illustrator', 'Photoshop', 'InDesign'].map((tech) => (
                  <span 
                    key={tech}
                    className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-full"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Order Section */}
            <Card className="bg-gradient-to-r from-peachy-light to-muted">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-navy mb-4">Order This Project</h3>
                <p className="text-muted-foreground mb-6">
                  Get a complete brand identity package that establishes your unique market presence.
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="font-medium">Starting Price:</span>
                    <span className="font-bold text-peachy">$30</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Delivery Time:</span>
                    <span className="font-bold">2-4 Days</span>
                  </div>
                  <Button className="w-full bg-peachy hover:bg-peachy/90 text-bright-yellow">
                    Order Now
                  </Button>
                  <Button variant="outline" className="w-full">
                    Contact for Custom Quote
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Detailed Description */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-navy mb-8">Project Details</h2>
          <div className="prose max-w-none">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-navy mb-4">Package Includes</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Custom logo design (5+ concepts)</li>
                  <li>• Color palette and variations</li>
                  <li>• Typography selection</li>
                  <li>• Brand guidelines document</li>
                  <li>• Business card design</li>
                  <li>• Letterhead and envelope design</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-navy mb-4">Deliverables</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Vector logo files (AI, EPS, SVG)</li>
                  <li>• High-resolution PNG/JPG formats</li>
                  <li>• Brand style guide (PDF)</li>
                  <li>• Color codes (HEX, RGB, CMYK)</li>
                  <li>• Font files and licensing info</li>
                  <li>• Social media kit</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrandIdentity;