import { ArrowLeft, ShoppingCart, Globe, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import groceryStoreDesign from '@/assets/grocery-store-design.jpg';

const GroceryStore = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-6 py-4">
          <Link to="/" className="inline-flex items-center text-navy hover:text-peachy transition-colors">
            <ArrowLeft size={20} className="mr-2" />
            Back to Portfolio
          </Link>
        </div>
      </header>

      {/* Project Details */}
      <div className="container mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Project Image */}
          <div className="space-y-6">
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img 
                src={groceryStoreDesign} 
                alt="Grocery Store Website Design"
                className="w-full h-auto"
              />
            </div>
          </div>

          {/* Project Info */}
          <div className="space-y-8">
            <div>
              <span className="inline-block px-3 py-1 bg-peachy-light text-peachy text-sm font-medium rounded-full mb-4">
                Web Development
              </span>
              <h1 className="text-4xl font-bold text-navy mb-4">
                Grocery Store Website
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Responsive e-commerce website for a local grocery store with shopping cart and payment integration. 
                Features include product catalog, inventory management, user accounts, order tracking, 
                and seamless checkout experience optimized for both mobile and desktop users.
              </p>
            </div>

            {/* Project Stats */}
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <ShoppingCart className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">500+</div>
                  <div className="text-sm text-muted-foreground">Products</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Globe className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">10-14</div>
                  <div className="text-sm text-muted-foreground">Days</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Users className="w-6 h-6 text-peachy mx-auto mb-2" />
                  <div className="text-2xl font-bold text-navy">1000+</div>
                  <div className="text-sm text-muted-foreground">Monthly Users</div>
                </CardContent>
              </Card>
            </div>

            {/* Technologies */}
            <div>
              <h3 className="text-xl font-semibold text-navy mb-4">Technologies Used</h3>
              <div className="flex flex-wrap gap-2">
                {['React', 'TypeScript', 'Tailwind CSS'].map((tech) => (
                  <span 
                    key={tech}
                    className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-full"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Order Section */}
            <Card className="bg-gradient-to-r from-peachy-light to-muted">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-navy mb-4">Order This Project</h3>
                <p className="text-muted-foreground mb-6">
                  Get a complete e-commerce website with all modern features and payment integration.
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="font-medium">Starting Price:</span>
                    <span className="font-bold text-peachy">$50</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Delivery Time:</span>
                    <span className="font-bold">3-5 Days</span>
                  </div>
                  <Button className="w-full bg-peachy hover:bg-peachy/90 text-bright-yellow">
                    Order Now
                  </Button>
                  <Button variant="outline" className="w-full">
                    Contact for Custom Quote
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Detailed Description */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-navy mb-8">Project Details</h2>
          <div className="prose max-w-none">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-navy mb-4">Key Features</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Responsive design for all devices</li>
                  <li>• Shopping cart and checkout system</li>
                  <li>• Payment gateway integration</li>
                  <li>• Product search and filtering</li>
                  <li>• User account management</li>
                  <li>• Order tracking system</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-navy mb-4">Technical Specifications</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Modern React architecture</li>
                  <li>• TypeScript for type safety</li>
                  <li>• Tailwind CSS for styling</li>
                  <li>• SEO optimized structure</li>
                  <li>• Performance optimized</li>
                  <li>• Cross-browser compatibility</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroceryStore;