import { ExternalLink, Github } from 'lucide-react';
import { Link } from 'react-router-dom';
import resumeTemplate from '@/assets/resume-template.png';
import diaryAppDesign from '@/assets/diary-app-design.jpg';
import groceryStoreDesign from '@/assets/grocery-store-design.jpg';
import brandIdentityPackage from '@/assets/brand-identity-package.jpg';
import socialMediaContent from '@/assets/social-media-content.jpg';

const Projects = () => {
  const projects = [
    {
      title: 'Professional Resume Designs',
      description: 'Modern, ATS-friendly resume templates with clean layouts and professional typography.',
      category: 'Design',
      image: resumeTemplate,
      tech: ['Adobe Illustrator', 'Figma', 'Canva'],
      color: 'bg-blue-50 border-blue-200',
      link: '/projects/resume-design'
    },
    {
      title: 'Diary App UI/UX',
      description: 'Clean and intuitive mobile app interface for a personal diary application with modern design patterns.',
      category: 'UI/UX Design',
      image: diaryAppDesign,
      tech: ['Figma', 'Adobe XD', 'Prototyping'],
      color: 'bg-purple-50 border-purple-200',
      link: '/projects/diary-app'
    },
    {
      title: 'Grocery Store Website',
      description: 'Responsive e-commerce website for a local grocery store with shopping cart and payment integration.',
      category: 'Web Development',
      image: groceryStoreDesign,
      tech: ['React', 'TypeScript', 'Tailwind CSS'],
      color: 'bg-green-50 border-green-200',
      link: '/projects/grocery-store'
    },
    {
      title: 'CGI Product Animations',
      description: 'High-quality 3D animations and CGI advertisements for various products and brands.',
      category: 'Animation',
      image: '/placeholder.svg',
      tech: ['Blender', 'After Effects', 'Cinema 4D'],
      color: 'bg-orange-50 border-orange-200',
      videoLink: 'https://www.kapwing.com/videos/688c8c0586223c45aedc713c',
      link: '/projects/cgi-animation'
    },
    {
      title: 'Brand Identity Package',
      description: 'Complete brand identity including logo design, color palette, and brand guidelines.',
      category: 'Branding',
      image: brandIdentityPackage,
      tech: ['Adobe Illustrator', 'Photoshop', 'InDesign'],
      color: 'bg-pink-50 border-pink-200',
      link: '/projects/brand-identity'
    },
    {
      title: 'Social Media Content',
      description: 'Engaging video content and animations for social media platforms and marketing campaigns.',
      category: 'Video Editing',
      image: socialMediaContent,
      tech: ['Premiere Pro', 'After Effects', 'DaVinci Resolve'],
      color: 'bg-red-50 border-red-200',
      link: '/projects/social-media-content'
    }
  ];

  return (
    <section id="projects" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
            Recent <span className="text-peachy">Projects</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A showcase of my latest work across different domains of digital creation
          </p>
          <div className="w-24 h-1 bg-peachy mx-auto rounded-full mt-6"></div>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Link 
              to={project.link}
              key={project.title}
              className="project-card fade-in group block"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Project Image */}
              <div className="relative overflow-hidden rounded-t-2xl bg-gradient-to-br from-peachy-light to-muted h-48">
                {project.image !== '/placeholder.svg' ? (
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-6xl text-peachy/30">
                      {project.category === 'Design' && '🎨'}
                      {project.category === 'UI/UX Design' && '📱'}
                      {project.category === 'Web Development' && '💻'}
                      {project.category === 'Animation' && '🎬'}
                      {project.category === 'Branding' && '🏷️'}
                      {project.category === 'Video Editing' && '🎥'}
                    </div>
                  </div>
                )}
                
                {/* Overlay on Hover */}
                <div className="absolute inset-0 bg-navy/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-4">
                  {project.videoLink ? (
                    <a 
                      href={project.videoLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-3 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
                    >
                      <ExternalLink size={20} className="text-bright-yellow" />
                    </a>
                  ) : (
                    <button className="p-3 bg-white/20 rounded-full hover:bg-white/30 transition-colors">
                      <ExternalLink size={20} className="text-bright-yellow" />
                    </button>
                  )}
                  <button className="p-3 bg-white/20 rounded-full hover:bg-white/30 transition-colors">
                    <Github size={20} className="text-bright-yellow" />
                  </button>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6">
                <div className="mb-3">
                  <span className="inline-block px-3 py-1 bg-peachy-light text-peachy text-sm font-medium rounded-full">
                    {project.category}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold text-navy mb-3 group-hover:text-peachy transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed mb-4">
                  {project.description}
                </p>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech) => (
                    <span 
                      key={tech}
                      className="px-3 py-1 bg-muted text-muted-foreground text-xs rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* View More Button */}
        <div className="text-center mt-12 fade-in">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-navy mb-4">Ready to Start Your Project?</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
              All projects are available at beginner-friendly prices! Perfect for students, startups, and small businesses.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 rounded-full font-semibold bg-peachy text-navy hover:bg-peachy/90 transition-all duration-300 shadow-glow"
              >
                Get Custom Quote
              </button>
              <a
                href="https://www.facebook.com/share/1AimpMZqT6/"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 rounded-full font-semibold text-navy border-2 border-navy hover:bg-navy hover:text-bright-yellow transition-all duration-300"
              >
                View More on Facebook
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;