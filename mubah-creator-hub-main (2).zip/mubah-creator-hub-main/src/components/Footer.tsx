const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="text-3xl font-bold text-bright-yellow">
              MH<span className="text-peachy">.</span>
            </div>
            <p className="text-bright-yellow/80 leading-relaxed">
              Digital Creator specializing in design, development, and animation. 
              Bringing creative visions to life through innovative digital solutions.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-xl font-semibold text-bright-yellow">Quick Links</h4>
            <div className="space-y-2">
              {['Home', 'About', 'Services', 'Projects', 'Contact'].map((link) => (
                <button
                  key={link}
                  onClick={() => {
                    const element = document.querySelector(`#${link.toLowerCase()}`);
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="block text-bright-yellow/80 hover:text-peachy transition-colors duration-300"
                >
                  {link}
                </button>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-xl font-semibold text-bright-yellow">Get in Touch</h4>
            <div className="space-y-2">
              <a 
                href="mailto:mhanxstudio@gmail.com"
                className="block text-bright-yellow/80 hover:text-peachy transition-colors duration-300"
              >
                mhanxstudio@gmail.com
              </a>
              <p className="text-bright-yellow/80">
                Available for freelance projects
              </p>
              <p className="text-bright-yellow/80">
                Response within 24 hours
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-bright-yellow/60">
              © {currentYear} Mubashir Hassan. All rights reserved.
            </p>
            <div className="flex items-center space-x-6">
              <p className="text-bright-yellow/60 text-sm">
                Built with passion and creativity
              </p>
              <div className="w-2 h-2 bg-peachy rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;