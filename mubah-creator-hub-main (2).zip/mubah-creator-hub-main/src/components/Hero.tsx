import { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import profilePicture from '@/assets/profile-picture.jpg';

const Hero = () => {
  const [currentSkill, setCurrentSkill] = useState(0);
  const skills = [
    'Graphics Designer',
    'Web Developer', 
    'Video Editor',
    'CGI Ads Expert',
    'UI/UX Designer',
    'Digital Creator'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSkill((prev) => (prev + 1) % skills.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [skills.length]);

  const scrollToAbout = () => {
    const aboutSection = document.querySelector('#about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center pt-20">
      <div className="container mx-auto px-6 relative">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-peachy/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-navy/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center relative z-10">
          {/* Text Content */}
          <div className="order-2 lg:order-1 fade-in">
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="relative">
                  <p className="text-sm font-medium text-primary/70 uppercase tracking-widest mb-2">Digital Creator</p>
                  <h1 className="text-5xl lg:text-7xl font-black leading-tight relative">
                    <span className="bg-gradient-to-r from-primary via-purple-500 to-cyan-400 bg-clip-text text-transparent animate-[pulse_3s_ease-in-out_infinite]">
                      Mubashir Hassan
                    </span>
                    <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 via-purple-500/20 to-cyan-400/20 blur-xl animate-[pulse_4s_ease-in-out_infinite] -z-10"></div>
                  </h1>
                </div>
              </div>
              
              <div className="space-y-8">
                <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary/5 via-purple-500/5 to-cyan-400/5 border border-primary/20 backdrop-blur-sm p-8">
                  <div className="flex flex-col space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                      <div className="text-lg font-medium text-muted-foreground">Currently</div>
                    </div>
                    <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-primary via-purple-500 to-cyan-400 bg-clip-text text-transparent">
                      {skills[currentSkill]}
                    </div>
                  </div>
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/10 to-transparent rounded-bl-full"></div>
                </div>
                
                <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl">
                  16-year-old creative specialist with 2+ years of experience in digital design, 
                  web development, and animated media. Transforming ideas into stunning digital experiences.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-6 pt-8">
                <button 
                  onClick={scrollToAbout}
                  className="hero-button group relative overflow-hidden"
                >
                  <span className="relative z-10">Get Started</span>
                  <div className="absolute inset-0 bg-shimmer bg-[length:200%_100%] animate-[shimmer_2s_infinite] opacity-0 group-hover:opacity-100"></div>
                </button>
                <button 
                  onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}
                  className="glass-card px-10 py-5 font-bold text-navy-light border-2 border-peachy/30 hover:border-peachy 
                           hover:bg-peachy/10 hover:text-peachy transition-all duration-500 hover:scale-105 hover:shadow-glow"
                >
                  View Work
                </button>
              </div>
            </div>
          </div>

          {/* Profile Image */}
          <div className="order-1 lg:order-2 flex justify-center slide-up">
            <div className="relative group">
              {/* Outer Rainbow Neon Ring */}
              <div className="absolute -inset-8 rounded-full animate-[rainbow-ring_4s_linear_infinite] opacity-80 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              {/* Middle Pulsing Ring */}
              <div className="absolute -inset-6 rounded-full bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 animate-[pulse-ring_3s_ease-in-out_infinite] opacity-60 blur-sm"></div>
              
              {/* Inner Rotating Ring */}
              <div className="absolute -inset-4 bg-neon-gradient rounded-full blur-lg opacity-70 group-hover:opacity-100 animate-[rotate-gradient_3s_linear_infinite]"></div>
              
              <div className="relative w-80 h-80 lg:w-96 lg:h-96 rounded-full overflow-hidden shadow-premium border-4 border-white/20 neon-ring">
                <img 
                  src={profilePicture} 
                  alt="Mubashir Hassan - Digital Creator" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-peachy/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
              
              {/* Enhanced Floating Elements */}
              <div className="absolute -top-6 -right-6 glass-card p-6 shadow-neon float-animation">
                <div className="w-4 h-4 bg-peachy rounded-full premium-glow"></div>
              </div>
              <div className="absolute -bottom-8 -left-8 glass-card p-8 shadow-neon float-animation" style={{ animationDelay: '2s' }}>
                <div className="w-5 h-5 bg-navy rounded-full premium-glow"></div>
              </div>
              <div className="absolute top-1/2 -right-12 glass-card p-4 shadow-neon float-animation" style={{ animationDelay: '4s' }}>
                <div className="w-3 h-3 bg-peachy-light rounded-full premium-glow"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Scroll Indicator */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex flex-col items-center space-y-4">
          <p className="text-navy-light text-lg font-medium">Scroll to explore</p>
          <button 
            onClick={scrollToAbout}
            className="glass-card p-4 text-peachy hover:text-peachy-light transition-all duration-500 
                     bounce-gentle hover:scale-110 hover:shadow-glow group"
          >
            <ChevronDown size={28} className="group-hover:animate-bounce" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;