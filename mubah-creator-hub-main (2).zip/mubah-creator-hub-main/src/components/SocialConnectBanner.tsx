import { Facebook, MessageCircle, Heart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const SocialConnectBanner = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-peachy-light/30 to-navy/5">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
            Stay Connected With Us! 
          </h2>
          <p className="text-lg text-navy-accent max-w-2xl mx-auto">
            Join our community for exclusive content, latest updates, and special offers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Facebook Card */}
          <Card className="project-card group border-blue-500/20 hover:border-blue-500/50 bg-gradient-to-br from-blue-50/80 to-blue-100/60 backdrop-blur-sm">
            <CardContent className="p-8 text-center relative overflow-hidden">
              {/* Animated Background */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10">
                <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Facebook className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-blue-900 mb-3">Follow Our Facebook Page</h3>
                <p className="text-blue-700 mb-6 text-sm">
                  Daily inspiration & creative content
                </p>
                
                <div className="flex justify-center space-x-4 mb-6">
                  <div className="flex items-center text-xs text-blue-600">
                    <Star className="h-3 w-3 mr-1" />
                    Updates
                  </div>
                  <div className="flex items-center text-xs text-blue-600">
                    <Heart className="h-3 w-3 mr-1" />
                    Community
                  </div>
                </div>

                <Button 
                  className="bg-blue-600 hover:bg-blue-700 text-bright-yellow px-6 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
                  onClick={() => window.open('https://www.facebook.com/share/1AimpMZqT6/', '_blank')}
                >
                  <Facebook className="mr-2 h-4 w-4" />
                  Follow Page
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* WhatsApp Card */}
          <Card className="project-card group border-green-500/20 hover:border-green-500/50 bg-gradient-to-br from-green-50/80 to-green-100/60 backdrop-blur-sm">
            <CardContent className="p-8 text-center relative overflow-hidden">
              {/* Animated Background */}
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/10 to-green-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <MessageCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-green-900 mb-3">Join WhatsApp Channel</h3>
                <p className="text-green-700 mb-6 text-sm">
                  Instant updates & exclusive offers
                </p>
                
                <div className="flex justify-center space-x-4 mb-6">
                  <div className="flex items-center text-xs text-green-600">
                    <Star className="h-3 w-3 mr-1" />
                    Instant
                  </div>
                  <div className="flex items-center text-xs text-green-600">
                    <Heart className="h-3 w-3 mr-1" />
                    Direct
                  </div>
                </div>

                <Button 
                  className="bg-green-600 hover:bg-green-700 text-bright-yellow px-6 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
                  onClick={() => window.open('https://wa.me/1234567890', '_blank')}
                >
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Join Channel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Special Offer Badge */}
        <div className="mt-12 text-center">
          <div className="inline-block p-6 glass-card max-w-md mx-auto">
            <div className="flex items-center justify-center mb-3">
              <Star className="h-5 w-5 text-yellow-500 mr-2" />
              <span className="text-lg font-bold gradient-text">Special Offer</span>
              <Star className="h-5 w-5 text-yellow-500 ml-2" />
            </div>
            <p className="text-sm text-navy-accent">
              Follow both channels to get <span className="font-bold text-peachy">20% OFF</span> your first project!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialConnectBanner;