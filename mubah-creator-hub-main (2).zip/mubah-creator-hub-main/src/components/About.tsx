const About = () => {
  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16 fade-in">
            <h2 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
              About <span className="text-peachy">Me</span>
            </h2>
            <div className="w-24 h-1 bg-peachy mx-auto rounded-full"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* About Content */}
            <div className="space-y-6 slide-up">
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-navy">
                  Passionate Digital Creator & Student
                </h3>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  As a Class 12 student, I'm a versatile digital creator with a strong command of various tools. 
                  I specialize in crafting engaging thumbnails and banners, producing dynamic animated and CGI 
                  advertisements, and building functional web and app experiences.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  I'm passionate about bringing ideas to life and constantly expanding my skills in the 
                  ever-evolving digital landscape. With over 2 years of freelance experience, I've helped 
                  numerous clients achieve their creative goals.
                </p>
              </div>

              {/* Education */}
              <div className="bg-card p-6 rounded-2xl shadow-elegant">
                <h4 className="text-xl font-semibold text-navy mb-3">Education</h4>
                <div className="space-y-2">
                  <p className="text-muted-foreground">
                    <span className="font-medium text-navy">Current:</span> Class 12 (Second Year)
                  </p>
                  <p className="text-muted-foreground">
                    <span className="font-medium text-navy">Focus:</span> Technology & Digital Media
                  </p>
                </div>
              </div>

              {/* Experience Highlight */}
              <div className="bg-peachy-light p-6 rounded-2xl border border-peachy/20">
                <h4 className="text-xl font-semibold text-navy mb-3">Experience Highlight</h4>
                <p className="text-muted-foreground">
                  <span className="font-bold text-peachy text-2xl">2+</span> years of freelance experience 
                  working with diverse clients across various digital media projects.
                </p>
              </div>
            </div>

            {/* Skills & Stats */}
            <div className="space-y-6 slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="grid grid-cols-2 gap-4">
                {/* Skill Cards */}
                <div className="bg-card p-6 rounded-2xl shadow-elegant text-center">
                  <div className="text-3xl font-bold text-peachy mb-2">50+</div>
                  <div className="text-muted-foreground">Projects Completed</div>
                </div>
                
                <div className="bg-card p-6 rounded-2xl shadow-elegant text-center">
                  <div className="text-3xl font-bold text-peachy mb-2">25+</div>
                  <div className="text-muted-foreground">Happy Clients</div>
                </div>
                
                <div className="bg-card p-6 rounded-2xl shadow-elegant text-center">
                  <div className="text-3xl font-bold text-peachy mb-2">6+</div>
                  <div className="text-muted-foreground">Specializations</div>
                </div>
                
                <div className="bg-card p-6 rounded-2xl shadow-elegant text-center">
                  <div className="text-3xl font-bold text-peachy mb-2">16</div>
                  <div className="text-muted-foreground">Years Young</div>
                </div>
              </div>

              {/* Core Values */}
              <div className="bg-navy p-6 rounded-2xl shadow-elegant">
                <h4 className="text-xl font-semibold text-bright-yellow mb-4">Core Values</h4>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-peachy rounded-full"></div>
                    <span className="text-bright-yellow/90">Creative Excellence</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-peachy rounded-full"></div>
                    <span className="text-bright-yellow/90">Technical Innovation</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-peachy rounded-full"></div>
                    <span className="text-bright-yellow/90">Client Satisfaction</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-peachy rounded-full"></div>
                    <span className="text-bright-yellow/90">Continuous Learning</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;