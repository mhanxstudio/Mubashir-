import { useState } from 'react';
import { Menu, X, Facebook, LogIn, LogOut, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ThemeToggle } from './ui/theme-toggle';
import { useAuth } from '@/hooks/useAuth';
import { Button } from './ui/button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, signOut } = useAuth();

  const navItems = [
    { href: '/welcome', label: 'Welcome', type: 'link' },
    { href: '#home', label: 'Home', type: 'scroll' },
    { href: '#about', label: 'About', type: 'scroll' },
    { href: '#services', label: 'Services', type: 'scroll' },
    { href: '#projects', label: 'Portfolio', type: 'scroll' },
    { href: '/blogs', label: 'Blogs', type: 'link' },
    { href: '#contact', label: 'Contact', type: 'scroll' }
  ];

  const handleNavClick = (item: any) => {
    if (item.type === 'scroll') {
      const element = document.querySelector(item.href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="text-2xl font-bold text-navy">
            MH<span className="text-peachy">.</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              item.type === 'link' ? (
                <Link
                  key={item.href}
                  to={item.href}
                  className="text-navy hover:text-peachy transition-colors font-medium"
                >
                  {item.label}
                </Link>
              ) : (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item)}
                  className="text-navy hover:text-peachy transition-colors font-medium"
                >
                  {item.label}
                </button>
              )
            ))}
            
            {/* Social & Theme Toggle */}
            <div className="flex items-center space-x-4">
              <a
                href="https://www.facebook.com/share/1AimpMZqT6/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-navy hover:text-peachy transition-colors"
              >
                <Facebook size={20} />
              </a>
              <ThemeToggle />
              
              {/* Auth Section */}
              {user ? (
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2 text-sm">
                    <User size={16} className="text-peachy" />
                    <span className="text-navy font-medium">
                      {user.user_metadata?.full_name || user.email}
                    </span>
                  </div>
                  <Button
                    onClick={signOut}
                    variant="ghost"
                    size="sm"
                    className="text-navy hover:text-peachy"
                  >
                    <LogOut size={16} className="mr-1" />
                    Sign Out
                  </Button>
                </div>
              ) : (
                <Link to="/auth">
                  <Button variant="ghost" size="sm" className="text-navy hover:text-peachy">
                    <LogIn size={16} className="mr-1" />
                    Sign In
                  </Button>
                </Link>
              )}
            </div>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-navy"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-border">
            <nav className="flex flex-col space-y-4 pt-4">
              {navItems.map((item) => (
                item.type === 'link' ? (
                  <Link
                    key={item.href}
                    to={item.href}
                    onClick={() => setIsMenuOpen(false)}
                    className="text-left text-navy hover:text-peachy transition-colors font-medium text-lg"
                  >
                    {item.label}
                  </Link>
                ) : (
                  <button
                    key={item.href}
                    onClick={() => handleNavClick(item)}
                    className="text-left text-navy hover:text-peachy transition-colors font-medium text-lg"
                  >
                    {item.label}
                  </button>
                )
              ))}
              
              {/* Mobile Social & Theme */}
              <div className="flex flex-col space-y-4 pt-4 border-t border-border">
                <div className="flex items-center space-x-4">
                  <a
                    href="https://www.facebook.com/share/1AimpMZqT6/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-navy hover:text-peachy transition-colors"
                  >
                    <Facebook size={20} />
                  </a>
                  <ThemeToggle />
                </div>
                
                {/* Mobile Auth Section */}
                {user ? (
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center space-x-2 text-sm">
                      <User size={16} className="text-peachy" />
                      <span className="text-navy font-medium">
                        {user.user_metadata?.full_name || user.email}
                      </span>
                    </div>
                    <Button
                      onClick={signOut}
                      variant="ghost"
                      size="sm"
                      className="text-navy hover:text-peachy justify-start"
                    >
                      <LogOut size={16} className="mr-1" />
                      Sign Out
                    </Button>
                  </div>
                ) : (
                  <Link to="/auth" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" size="sm" className="text-navy hover:text-peachy justify-start">
                      <LogIn size={16} className="mr-1" />
                      Sign In
                    </Button>
                  </Link>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;