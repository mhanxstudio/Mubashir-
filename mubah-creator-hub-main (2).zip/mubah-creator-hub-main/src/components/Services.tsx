import { 
  Globe, 
  FileText, 
  Code, 
  Palette, 
  Video, 
  Zap 
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Globe,
      title: 'Web Design',
      description: 'Modern, responsive websites that look great on all devices. From landing pages to full web applications.',
      color: 'text-blue-500'
    },
    {
      icon: FileText,
      title: 'Resume Creation',
      description: 'Professional, ATS-friendly resumes that help you stand out and land your dream job.',
      color: 'text-green-500'
    },
    {
      icon: Code,
      title: 'Front-End Development',
      description: 'Interactive web applications built with modern technologies like React, TypeScript, and Tailwind CSS.',
      color: 'text-purple-500'
    },
    {
      icon: Palette,
      title: 'Graphic Design',
      description: 'Eye-catching visual designs including logos, banners, thumbnails, and complete brand identities.',
      color: 'text-pink-500'
    },
    {
      icon: Video,
      title: 'Video Editing',
      description: 'Professional video editing for social media, marketing content, and promotional materials.',
      color: 'text-red-500'
    },
    {
      icon: Zap,
      title: 'CGI Animated Ads',
      description: 'Dynamic 3D animations and CGI advertisements that capture attention and drive engagement.',
      color: 'text-yellow-500'
    }
  ];

  return (
    <section id="services" className="py-20">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
            My <span className="text-peachy">Services</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            I offer a comprehensive range of digital services to help bring your creative vision to life
          </p>
          <div className="w-24 h-1 bg-peachy mx-auto rounded-full mt-6"></div>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={service.title}
              className="service-card fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="mb-6">
                <div className={`inline-flex p-4 rounded-full bg-muted ${service.color}`}>
                  <service.icon size={32} />
                </div>
              </div>
              
              <h3 className="text-xl font-bold text-navy mb-4">
                {service.title}
              </h3>
              
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>

              {/* Hover Effect Arrow */}
              <div className="mt-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="flex items-center text-peachy font-medium">
                  <span>Learn More</span>
                  <svg 
                    className="w-4 h-4 ml-2 transform transition-transform group-hover:translate-x-1" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16 fade-in">
          <p className="text-lg text-muted-foreground mb-6">
            Ready to start your project?
          </p>
          <button 
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="hero-button"
          >
            Let's Work Together
          </button>
        </div>
      </div>
    </section>
  );
};

export default Services;