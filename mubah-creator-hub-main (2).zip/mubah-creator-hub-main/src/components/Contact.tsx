import { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageCircle } from 'lucide-react';
import emailjs from '@emailjs/browser';
import { toast } from '@/hooks/use-toast';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await emailjs.send(
        'service_qgh7epi',
        'template_fncq6yg',
        {
          from_name: formData.name,
          from_email: formData.email,
          message: formData.message,
          to_email: 'mhanxstudio@gmail.com'
        },
        'sXf4fx9TSyShdmvNz'
      );

      toast({
        title: "Message sent successfully!",
        description: "Thank you for reaching out. I'll get back to you within 24 hours.",
      });

      // Reset form
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      console.error('Email send error:', error);
      toast({
        title: "Failed to send message",
        description: "Please try again or contact me directly at mhanxstudio@gmail.com",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
            Let's <span className="text-peachy">Connect</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Ready to bring your project to life? Let's discuss how we can work together 
            to create something amazing.
          </p>
          <div className="w-24 h-1 bg-peachy mx-auto rounded-full mt-6"></div>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8 slide-up">
              <div>
                <h3 className="text-2xl font-bold text-navy mb-6">Get in Touch</h3>
                <p className="text-muted-foreground leading-relaxed mb-8">
                  I'm always excited to discuss new projects and opportunities. 
                  Whether you need design work, development, or creative consultation, 
                  I'm here to help bring your vision to reality.
                </p>
              </div>

              {/* Contact Details */}
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-peachy-light rounded-full flex items-center justify-center">
                    <Mail className="text-peachy" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">Email</h4>
                    <a 
                      href="mailto:mhanxstudio@gmail.com"
                      className="text-muted-foreground hover:text-peachy transition-colors"
                    >
                      mhanxstudio@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-peachy-light rounded-full flex items-center justify-center">
                    <Phone className="text-peachy" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">Response Time</h4>
                    <p className="text-muted-foreground">Within 24 hours</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-peachy-light rounded-full flex items-center justify-center">
                    <MapPin className="text-peachy" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">Availability</h4>
                    <p className="text-muted-foreground">Open for freelance projects</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <MessageCircle className="text-green-600" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">WhatsApp Channel</h4>
                    <a 
                      href="https://whatsapp.com/channel/0029VayxwuxDp2QH5C0lse3A"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-green-600 transition-colors"
                    >
                      Join my channel
                    </a>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="bg-navy p-6 rounded-2xl shadow-elegant">
                <h4 className="text-xl font-semibold text-bright-yellow mb-4">Why Work With Me?</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-peachy">2+</div>
                    <div className="text-bright-yellow/80 text-sm">Years Experience</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-peachy">24h</div>
                    <div className="text-bright-yellow/80 text-sm">Response Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-peachy">50+</div>
                    <div className="text-bright-yellow/80 text-sm">Projects Done</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-peachy">100%</div>
                    <div className="text-bright-yellow/80 text-sm">Satisfaction</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="bg-card p-8 rounded-2xl shadow-elegant">
                <h3 className="text-2xl font-bold text-navy mb-6">Send a Message</h3>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-navy font-medium mb-2">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-border rounded-xl focus:ring-2 focus:ring-peachy focus:border-transparent transition-all duration-300"
                      placeholder="Enter your name"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-navy font-medium mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-border rounded-xl focus:ring-2 focus:ring-peachy focus:border-transparent transition-all duration-300"
                      placeholder="Enter your email"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-navy font-medium mb-2">
                      Project Details *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-border rounded-xl focus:ring-2 focus:ring-peachy focus:border-transparent transition-all duration-300 resize-none"
                      placeholder="Tell me about your project..."
                    />
                  </div>

                <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full hero-button flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send size={20} />
                    <span>{isLoading ? 'Sending...' : 'Send Message'}</span>
                  </button>
                </form>

                {/* Alternative Contact */}
                <div className="mt-6 pt-6 border-t border-border">
                  <p className="text-muted-foreground text-center">
                    Prefer email directly?{' '}
                    <a 
                      href="mailto:mhanxstudio@gmail.com"
                      className="text-peachy font-medium hover:underline"
                    >
                      mhanxstudio@gmail.com
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;